﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;


public class ButtonScript : MonoBehaviour
{
    public Toggle USD;
    public Toggle JPY;
    public Toggle KRW;
    public Toggle MYR;
    public Toggle ERP;
    public Toggle TWD;
    // Start is called before the first frame update
    void Start()
    {
        USD.isOn = true;
        JPY.isOn = true;
        KRW.isOn = true;
        MYR.isOn = true;
        ERP.isOn = true;
        TWD.isOn = true;
    }

    // Update is called once per frame
    public void USDButton()
    {
        if (USD.isOn == true)
        {
            JPY.isOn = false;
            KRW.isOn = false;
            MYR.isOn = false;
            TWD.isOn = false;
            ERP.isOn = false;
        }
    
    }
    public void JPYButton()
    {
        if (JPY.isOn == true)
        {
            USD.isOn = false;
            KRW.isOn = false;
            MYR.isOn = false;
            TWD.isOn = false;
            ERP.isOn = false;
        }
    }
    public void KRWButton()
    {
        if (KRW.isOn == true)
        {
            MYR.isOn = false;
            USD.isOn = false;
            JPY.isOn = false;
            TWD.isOn = false;
            ERP.isOn = false;
        }
    }
    public void MYRButton()
    {
        if (MYR.isOn == true)
        {
            KRW.isOn = false;
            USD.isOn = false;
            JPY.isOn = false;
            TWD.isOn = false;
            ERP.isOn = false;
        }
    }
    public void TWDButton()
    {
        if (TWD.isOn == true)
        {
            KRW.isOn = false;
            USD.isOn = false;
            JPY.isOn = false;
            MYR.isOn = false;
            ERP.isOn = false;
        }
    }
    public void ERPButton()
    {
        if (ERP.isOn == true)
        {
            KRW.isOn = false;
            USD.isOn = false;
            JPY.isOn = false;
            TWD.isOn = false;
            MYR.isOn = false;
        }
    }
}
