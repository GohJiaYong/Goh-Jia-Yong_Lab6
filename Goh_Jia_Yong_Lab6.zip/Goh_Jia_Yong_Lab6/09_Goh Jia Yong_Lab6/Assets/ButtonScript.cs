﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;


public class ButtonScript : MonoBehaviour
{
    public Toggle USD;
    public Toggle JPY;
    // Start is called before the first frame update
    void Start()
    {
        USD.isOn = true;
        USD.isOn = true;
    }

    // Update is called once per frame
    public void USDButton()
    {
        if (USD.isOn == true)
        {
            JPY.isOn = false;
        }
    
    }
    public void JPYButton()
    {
        if (JPY.isOn == true)
        {
            USD.isOn = false;
        }
    }
}
