﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;


public class Converter : MonoBehaviour
{
    public InputField InputAmount;
    public InputField TotalValue;

    public Toggle USD;
    public Toggle JPY;
    public Toggle KRW;
    public Toggle MYR;
    public Toggle ERP;
    public Toggle TWD;

    public float SGDUSD = 0.74f;
    public float SGDYEN = 82.78f;
    public float SGDWON = 937.88f;
    public float SGDRIN = 3.27f;
    public float SGDEURO = 0.70f;
    public float SGDTWD = 22.93f;

    float Amount;

    // Start is called before the first frame update
    void Start()
    {
      
    }

    // Update is called once per frame
    public void Convert()
    {
        Amount = float.Parse(InputAmount.text);

        if (USD.isOn == true)
        {
            JPY.isOn = false;
            TotalValue.text = "$" + (Amount * SGDUSD);
        }
        else if (JPY.isOn == true)
        {
            USD.isOn = false;
            TotalValue.text = "$" + (Amount * SGDYEN);

        }
        else if (KRW.isOn == true)
        {
            KRW.isOn = false;
            TotalValue.text = "$" + (Amount * SGDWON);
        }
        else if (MYR.isOn == true)
        {
            MYR.isOn = false;
            TotalValue.text = "$" + (Amount * SGDRIN);
        }
        else if (ERP.isOn == true)
        {
            ERP.isOn = false;
            TotalValue.text = "$" + (Amount * SGDEURO);
        }
        else if (TWD.isOn == true)
        {
            TWD.isOn = false;
            TotalValue.text = "$" + (Amount * SGDTWD);
        }
    }
    public void onClear()
    {
        USD.isOn = false;
        JPY.isOn = false;
        KRW.isOn = false;
        MYR.isOn = false;
        TWD.isOn = false;
        ERP.isOn = false;
        InputAmount.text = "";
        TotalValue.text = "";
    }
}
