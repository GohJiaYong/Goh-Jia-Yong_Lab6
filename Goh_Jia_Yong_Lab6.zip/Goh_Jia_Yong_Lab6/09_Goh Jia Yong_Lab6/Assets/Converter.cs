﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;


public class Converter : MonoBehaviour
{
    public InputField InputAmount;
    public InputField TotalValue;

    public Toggle USD;
    public Toggle JPY;

    public float SGDUSD = 0.74f;
    public float SGDYEN = 82.78f;

    float Amount;

    // Start is called before the first frame update
    void Start()
    {
      
    }

    // Update is called once per frame
    public void Convert()
    {
        Amount = float.Parse(InputAmount.text);

        if (USD.isOn == true)
        {
            JPY.isOn = false;
            TotalValue.text = "$" + (Amount * SGDUSD);
        }
        else if (JPY.isOn == true)
        {
            USD.isOn = false;
            TotalValue.text = "$" + (Amount * SGDYEN);

        }
    }
    public void onClear()
    {
        USD.isOn = false;
        JPY.isOn = false;
        InputAmount.text = "";
        TotalValue.text = "";
    }
}
